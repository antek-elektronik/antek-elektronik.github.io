function mainpage(){
    window.location = "index.html";
}

function producenci(){
    window.location = "producenci.html";
}

function budowa(){
    window.location = "budowa.html";
}

function rozmiary(){
    window.location = "rozmiary.html";
}

function autor(){
    window.location = "autor.html";
}